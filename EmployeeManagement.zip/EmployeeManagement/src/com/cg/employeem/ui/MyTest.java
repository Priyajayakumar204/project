package com.cg.employeem.ui;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.cg.employeem.dto.Employee;
import com.cg.employeem.exception.EmployeeException;
import com.cg.employeem.service.EmployeeService;
import com.cg.employeem.service.EmployeeServiceImpl;

public class MyTest {
	
		public static void main(String[] args){
			int choice=0;
			//creating object service layer
			EmployeeService empSer=new EmployeeServiceImpl();
			
			do{
				Scanner scr=new Scanner(System.in);
				printDetail();
				System.out.println("Enter the choice");
				choice=scr.nextInt();
				switch(choice){
				case 1://add
					//System.out.println("Enter the employee ID");
					//int empId=scr.nextInt();
					try{
					System.out.println("Enter the EMployee Name");
					String empName=scr.next();
					String patName="[A-Z][a-z]{3,19}";
					EmployeeServiceImpl.validateName(empName, patName);
					System.out.println("enter the designation");
					String empDeg=scr.next();
					System.out.println("Enter employee salary");
					double sal=scr.nextDouble();
					
					Employee emp=new Employee(); //dto
					//emp.setEmpId(empId);
					emp.setEmpName(empName);
					emp.setEmpDeg(empDeg);
					emp.setEmpSalary(sal);
					
					/*try {*/
						int empid=empSer.addEmployee(emp);
						System.out.println("data inserted & empid is"+empid);
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
						System.out.println(e.getMessage());
					}
					
					break;
				case 2://show all
					List<Employee> empList=null;
					try {
						empList=empSer.showAll();
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						System.out.println(e.getMessage());
					}
					for(Employee emplo:empList)
					{
						System.out.println("Id is "+emplo.getEmpId());
						System.out.println("Name is "+emplo.getEmpName());
						System.out.println("designation is "+emplo.getEmpDeg());
						System.out.println("salary is "+emplo.getEmpSalary());
					}
					break;
				case 3://search
					System.out.println("enter the employee ID");
					int empI=scr.nextInt();
					Employee empO=null;
					try {
						empO=empSer.search(empI);
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						System.out.println(e.getMessage());
					}
					
					if(empO.getEmpName()!=null)
					{
						System.out.println("Id is "+empO.getEmpId());
						System.out.println("Name is "+empO.getEmpName());
						System.out.println("designation is "+empO.getEmpDeg());
						System.out.println("salary is "+empO.getEmpSalary());
					}
					else
					{
						System.out.println("invalid employee ID");
					}
					
					break;
				case 4: //remove
					System.out.println("enter the employee ID to be removed");
					int empd=scr.nextInt();
					
					try {
						empSer.removeData(empd);
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case 5: //sort
					//List<Employee> empSort=empSer.showAll();
					//Collections.sort(empSort);  //compareTo()
					break;
				case 6: //exit
					break;
				}
			}while(choice!=6);
			
		}
		public static void printDetail(){
			System.out.println("******* Employee Management**********");
			System.out.println("1. Add Employee");
			System.out.println("2. Show All");
			System.out.println("3. Search Emp");
			System.out.println("4. Remove");
		
			System.out.println("*************************************");
			
		}
}
