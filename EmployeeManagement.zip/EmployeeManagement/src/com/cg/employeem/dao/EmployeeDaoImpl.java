package com.cg.employeem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.employeem.dto.Employee;
import com.cg.employeem.exception.EmployeeException;
import com.cg.employeem.util.Dbutil;

public class EmployeeDaoImpl implements EmployeeDao {
	static Connection con=null;
	static PreparedStatement pstm=null;
	private static final Logger myLogger=
			Logger.getLogger(EmployeeDaoImpl.class);
	@Override
	public int addEmployeeDb(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		int empId=0;
		try {
			con=Dbutil.getConnection();
			String query="INSERT INTO EMPO VALUES(?,?,?,?)";
			empId=getEmployeeID();//from getEmployeeID()
			pstm=con.prepareStatement(query);
			pstm.setInt(1, empId);
			pstm.setString(2, emp.getEmpName());
			pstm.setString(3, emp.getEmpDeg());
			pstm.setDouble(4, emp.getEmpSalary());
			int status=pstm.executeUpdate();
			if(status==1)
			{
				myLogger.info("Data Inserted iwth employee Id"+empId);
			}
			else
			{
				System.out.println("not inserted");
			}
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			myLogger.info("Insert Problem"+e.getMessage());
			e.printStackTrace();
			throw new EmployeeException("Insert having problem");
			
		}finally{
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeException("problem in closing");
			}
			
			
		}
		return empId;
		
	}

	@Override
	public List<Employee> showAllDb() throws EmployeeException {
		// TODO Auto-generated method stub
		List<Employee> myList=new ArrayList<Employee>();
		try {
			
			
			con=Dbutil.getConnection();
			String queryTwo="SELECT emp_id,emp_name,emp_deg,emp_sal FROM EMPO";
			pstm=con.prepareStatement(queryTwo);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				
				Employee emp=new Employee();
				
				emp.setEmpId(res.getInt("emp_id"));
				emp.setEmpName(res.getString("emp_name"));
				emp.setEmpDeg(res.getString("emp_deg"));
				emp.setEmpSalary(res.getDouble("emp_sal"));
			
				myList.add(emp);
				
				//print
				
			}
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close");
			}
			
		}
		
		return myList;
	}

	@Override
	public Employee searchEmp(int empId) throws EmployeeException {
		Employee emp=new Employee();
		try {
			con=Dbutil.getConnection();
			String query="SELECT emp_id,emp_name,emp_deg,emp_sal FROM EMPO WHERE emp_id=? ";
			pstm=con.prepareStatement(query);
			pstm.setInt(1, empId);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				emp.setEmpId(res.getInt("emp_id"));
				emp.setEmpName(res.getString("emp_name"));
				emp.setEmpDeg(res.getString("emp_deg"));
				emp.setEmpSalary(res.getDouble("emp_sal"));
		} }catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("problem in search,enter valid Employee ID");
		}finally
		{
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("problem in closing");
			}
			
			
		}
		// TODO Auto-generated method stub
		return emp;
	}
	
	@Override
	public void removeDataDb(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		try {
			con=Dbutil.getConnection();
			String query="DELETE FROM empo WHERE emp_id=? ";
			pstm=con.prepareStatement(query);
			pstm.setInt(1, empId);
			int status=pstm.executeUpdate();
			if(status==1)
			{
					System.out.println("data deleted");
				}
				else
				{
					throw new EmployeeException("failed to delete");
					
				}
			}
			catch(SQLException | EmployeeException e)
			{
			e.printStackTrace();
			System.out.println("could not find id to be deleted");
			}
			finally{
				try{
					pstm.close();
					
					con.close();
				}catch(SQLException e1)
				{
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}
			}
		
	}
	public static int getEmployeeID(){
		int empId=0;
		try {
			con=Dbutil.getConnection();
			String query="SELECT emp_id_seq.nextval FROM DUAL";
			pstm=con.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				empId=res.getInt(1);
			}
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return empId;
	}
	
	

}


/*ArrayList<Employee> myList=new ArrayList<Employee>();


@Override
public void addEmployeeDb(Employee emp) {
	// TODO Auto-generated method stub
	myList.add(emp);
	
	
}

@Override
public List<Employee> showAllDb() {
	// TODO Auto-generated method stub
	return myList;
}

@Override
public Employee searchEmp(int empId) {
	// TODO Auto-generated method stub
	Employee emp=null;
	for(Employee emplo:myList)
	{
		if(emplo.getEmpId()==empId){
			emp=emplo;
			break;
		}
	}
	return emp;
}

@Override
public void removeDataDb(int empId) {
	// TODO Auto-generated method stub
	int empI=empId;
	Employee empobj;
	for(Employee emplo:myList)
	{
		if(emplo.getEmpId()==empI)
		{
			
			myList.remove(emplo);
			System.out.println("employee removed");
		}else
		{
			System.out.println("element not found");
		}
	}
	
	
}
*/