package com.cg.employeem.dao;

import java.util.List;

import com.cg.employeem.dto.Employee;
import com.cg.employeem.exception.EmployeeException;

public interface EmployeeDao {

	
			public int addEmployeeDb(Employee emp) throws EmployeeException;
			public List<Employee> showAllDb()  throws EmployeeException;
			public Employee searchEmp(int empId) throws EmployeeException;
			public void removeDataDb(int empId)  throws EmployeeException;
}
