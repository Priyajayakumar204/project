package com.cg.employeem.junittest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.employeem.exception.EmployeeException;
import com.cg.employeem.util.Dbutil;

public class EmployeeDaoImplTest {
	Connection con=null;
	PreparedStatement pstm=null;
		@Before
		public void beforeTest() throws EmployeeException, SQLException{
			con=Dbutil.getConnection();
			String query="INSERT INTO EMPO VALUES(?,?,?,?)";
			pstm=con.prepareStatement(query);
			pstm.setInt(1, 1078);
			pstm.setString(2, "abcd");
			pstm.setString(3, "it");
			pstm.setDouble(4,21.22);
		}
		@Test
		public void myTest() throws SQLException{
			assertEquals(1,pstm.executeUpdate());
;		}
		@After
		public void afterTest(){
			
		}

}
