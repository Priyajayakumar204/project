package com.cg.employeem.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.cg.employeem.exception.EmployeeException;

public class Dbutil {
	static Connection conn=null;
	private static final Logger myLog=Logger.getLogger(Dbutil.class);
	public static Connection getConnection() throws EmployeeException{
		try {
			FileInputStream fRead=new FileInputStream("oracle.properties");
			Properties prop=new Properties();
			prop.load(fRead);
			String driver=prop.getProperty("oracle.driver");
			String url=prop.getProperty("oracle.url");
			String uname=prop.getProperty("oracle.username");
			String upass=prop.getProperty("oracle.password");
			Class.forName(driver); //loading the driver
			//establish the connection..
			conn= DriverManager.getConnection(url,uname,upass);
			myLog.info("connection established");
			System.out.println("connection established..........");
		} catch (IOException | ClassNotFoundException | SQLException e ) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLog.info("non connection"+e.getMessage());
		throw new EmployeeException("no connection");
		}
		
		return conn;
	}
}
