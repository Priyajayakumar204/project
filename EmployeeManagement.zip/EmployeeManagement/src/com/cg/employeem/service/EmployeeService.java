package com.cg.employeem.service;

import java.util.List;

import com.cg.employeem.dto.Employee;
import com.cg.employeem.exception.EmployeeException;

public interface EmployeeService {

			public int addEmployee(Employee emp) throws EmployeeException;
			public List<Employee> showAll() throws EmployeeException;
			public Employee search(int empId) throws EmployeeException;
			public void removeData(int empId)  throws EmployeeException;
			
			
}
