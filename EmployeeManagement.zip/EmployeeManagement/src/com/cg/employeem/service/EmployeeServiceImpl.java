package com.cg.employeem.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.employeem.dao.EmployeeDao;
import com.cg.employeem.dao.EmployeeDaoImpl;
import com.cg.employeem.dto.Employee;
import com.cg.employeem.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDao empDao=new EmployeeDaoImpl();
	
	

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.addEmployeeDb(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException{
		// TODO Auto-generated method stub
		
		return empDao.showAllDb();
	}

	@Override
	public Employee search(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.searchEmp(empId);
	}

	@Override
	public void removeData(int empId)  throws EmployeeException {
		// TODO Auto-generated method stub
		empDao.removeDataDb(empId);
		
	}
	public static void  validateName(String name,String patt) throws EmployeeException{
		boolean msg=Pattern.matches(patt, name);
		if(!msg){
			throw new EmployeeException("name first letter should be capital and max length is 20");
		}
		
	}
	

			
}
