package com.cg.employeem.dto;

public class Employee implements Comparable<Employee> {

		private int empId;
		private String empName;
		private String empDeg;
		private double empSalary;
		
		
		public Employee() {
			super();
		}
		
		public Employee(int empId, String empName, String empDeg,
				double empSalary) {
			super();
			this.empId = empId;
			this.empName = empName;
			this.empDeg = empDeg;
			this.empSalary = empSalary;
		}

		@Override
		public String toString() {
			return "Employee [empId=" + empId + ", empName=" + empName
					+ ", empDeg=" + empDeg + ", empSalary=" + empSalary + "]";
		}
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getEmpDeg() {
			return empDeg;
		}
		public void setEmpDeg(String empDeg) {
			this.empDeg = empDeg;
		}
		public double getEmpSalary() {
			return empSalary;
		}
		public void setEmpSalary(double empSalary) {
			this.empSalary = empSalary;
		}

		@Override
		public int compareTo(Employee o1) {
			// TODO Auto-generated method stub
			if(this.getEmpId()==o1.getEmpId())
			return 0;
			else if(this.getEmpId()>o1.getEmpId())
				return 1;
			else
				return -1;
				
		}
	
}
