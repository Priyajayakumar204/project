package com.cg.springmobile.dao;

import java.util.List;

import com.cg.springmobile.dto.Mobile;

public interface IMobileDao {

	
	public int addMobile(Mobile mob);
	public List<Mobile> showAllProduct();
	public List<Mobile> searchProduct(int prodId);
	public int removemobiledata(int delid);
}
