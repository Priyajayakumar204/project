package com.cg.springmobile.service;

import java.util.List;

import com.cg.springmobile.dto.Mobile;


public interface IMobileService {

	
	public int addMobile(Mobile mob);
	public List<Mobile> showAll();
	public List<Mobile> searchProduct(int prodId);
	public int removemobile(int delid);
}
