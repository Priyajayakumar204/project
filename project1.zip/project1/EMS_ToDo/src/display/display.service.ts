import { Injectable,Inject } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Employee } from './employee';

@Injectable()
export class DisplayService{
    
    private url = 'src/display/employees.json';
    
    constructor(@Inject(Http) private http:Http){
        
    }
    
    getAllEmps():Observable<Employee[]>{
        return this.http.get(this.url).map((response:Response)=><Employee[]>response.json()).catch(this.handleError);
    }
    
    private handleError(error:Response){
        console.log(error);
        return Observable.throw(error.json().error || 'Server Error');
    }
}